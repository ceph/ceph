import tox

if __name__ == "__main__":
    tox.cmdline()
