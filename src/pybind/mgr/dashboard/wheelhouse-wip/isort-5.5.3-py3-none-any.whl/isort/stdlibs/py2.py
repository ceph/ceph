from . import py27

stdlib = py27.stdlib
